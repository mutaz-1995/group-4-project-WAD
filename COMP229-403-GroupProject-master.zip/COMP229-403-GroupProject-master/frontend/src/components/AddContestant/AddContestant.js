import React, { useState } from 'react';
import { createContestant } from '../../api/api';
import './AddContestant.css';

const AddContestant = () => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [partyDescription, setPartyDescription] = useState('');
  const [picture, setPicture] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Convert age to a number before sending
    const newContestant = {
      name,
      age: parseInt(age, 10), // Ensure age is sent as a number
      partyDescription,
      picture,
    };
  
    try {
      await createContestant(newContestant);
      alert('Contestant added successfully!');
      setName('');
      setAge('');
      setPartyDescription('');
      setPicture('');
    } catch (err) {
      console.error('Error adding contestant:', err);
      alert('Failed to add contestant.');
    }
  };

  return (
    <div className="add-contestant">
      <h2>Add a New Contestant</h2>
      <form onSubmit={handleSubmit} className="add-contestant-form">
        <label>Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <label>Age</label>
        <input
          type="number"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          required
        />
        <label>Party Description</label>
        <input
          type="text"
          value={partyDescription}
          onChange={(e) => setPartyDescription(e.target.value)}
          required
        />
        <label>Picture URL</label>
        <input
          type="text"
          value={picture}
          onChange={(e) => setPicture(e.target.value)}
        />
        <button type="submit" className="submit-button">
          Add Contestant
        </button>
      </form>
    </div>
  );
};

export default AddContestant;
