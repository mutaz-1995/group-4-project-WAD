import React from 'react';
import './ContestantCard.css';
import { castVote } from '../../api/api'; // API call for voting

const ContestantCard = ({ contestant, onVote }) => {
  // Handle voting action
  const handleVote = async () => {
    try {
      // Cast a vote for the given contestant
      await castVote(contestant._id, "Anonymous Voter");
      alert(`You voted for ${contestant.name}!`); // Success feedback
      onVote(); // Callback to refresh the contestant list
    } catch (err) {
      console.error('Error voting:', err); // Log error
      alert('Failed to cast vote. Please try again.'); // Error feedback
    }
  };

  return (
    <div className="contestant-card">
      {/* Contestant image with fallback to default */}
      <img
        src={contestant.picture || '/default-avatar.png'} // Placeholder image if no URL
        alt={contestant.name}
        className="contestant-image"
      />

      {/* Contestant info */}
      <div className="contestant-info">
        <h3>{contestant.name}</h3>
        <p><strong>Age:</strong> {contestant.age}</p>
        <p><strong>Party:</strong> {contestant.partyDescription}</p>
        <p><strong>Votes:</strong> {contestant.votes}</p>
        
        {/* Voting button */}
        <button onClick={handleVote} className="vote-button">Vote</button>
      </div>
    </div>
  );
};

export default ContestantCard;
