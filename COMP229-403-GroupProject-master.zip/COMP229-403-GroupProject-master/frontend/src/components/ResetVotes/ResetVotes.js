import React from 'react';
import { resetVotes } from '../../api/api';
import './ResetVotes.css';

const ResetVotes = () => {
  const handleReset = async () => {
    try {
      if (window.confirm('Are you sure you want to reset all votes?')) {
        await resetVotes();
        alert('Votes have been reset successfully!');
      }
    } catch (err) {
      console.error('Error resetting votes:', err);
      alert('Failed to reset votes.');
    }
  };

  return (
    <div className="reset-votes">
      <h2>Reset All Votes</h2>
      <button onClick={handleReset} className="reset-button">
        Reset Votes
      </button>
    </div>
  );
};

export default ResetVotes;
