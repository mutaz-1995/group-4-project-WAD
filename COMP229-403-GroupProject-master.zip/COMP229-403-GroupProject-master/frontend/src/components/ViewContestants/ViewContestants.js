import React, { useState, useEffect } from 'react';
import './ViewContestants.css';
import { getContestants, updateContestant } from '../../api/api';

const ViewContestants = () => {
  const [contestants, setContestants] = useState([]);
  const [editingContestant, setEditingContestant] = useState(null);
  const [updatedContestant, setUpdatedContestant] = useState({ name: '', age: '', partyDescription: '', picture: '' });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const fetchContestants = async () => {
      try {
        const response = await getContestants();
        setContestants(response); // Response directly sets contestants
      } catch (err) {
        console.error('Failed to fetch contestants:', err);
      }
    };
    fetchContestants();
  }, []);

  const handleEditClick = (contestant) => {
    setEditingContestant(contestant._id);
    setUpdatedContestant({
      name: contestant.name,
      age: contestant.age,
      partyDescription: contestant.partyDescription,
      picture: contestant.picture,
    });
  };

  const handleSave = async () => {
    if (!updatedContestant.name || !updatedContestant.age || !updatedContestant.partyDescription) {
      alert('Please fill in all required fields!');
      return;
    }

    setIsSaving(true);
    try {
      await updateContestant(editingContestant, updatedContestant);
      alert('Contestant updated successfully!');
      setEditingContestant(null);
      setIsSaving(false);

      const updatedList = contestants.map((c) =>
        c._id === editingContestant ? { ...c, ...updatedContestant } : c
      );
      setContestants(updatedList);
    } catch (err) {
      console.error('Failed to update contestant:', err);
      alert('Failed to update contestant.');
      setIsSaving(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdatedContestant((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleCancel = () => {
    setEditingContestant(null);
    setUpdatedContestant({ name: '', age: '', partyDescription: '', picture: '' });
  };

  return (
    <div className="view-contestants">
      <h2>View Contestants</h2>
      {contestants.length === 0 ? (
        <p>No contestants found. Add a contestant to get started!</p>
      ) : (
        <div className="contestants-list">
          {contestants.map((contestant) => (
            <div key={contestant._id} className="contestant-card">
              {editingContestant === contestant._id ? (
                <div className="edit-form">
                  <input
                    type="text"
                    name="name"
                    value={updatedContestant.name}
                    onChange={handleInputChange}
                    placeholder="Name"
                  />
                  <input
                    type="number"
                    name="age"
                    value={updatedContestant.age}
                    onChange={handleInputChange}
                    placeholder="Age"
                  />
                  <input
                    type="text"
                    name="partyDescription"
                    value={updatedContestant.partyDescription}
                    onChange={handleInputChange}
                    placeholder="Party Description"
                  />
                  <input
                    type="text"
                    name="picture"
                    value={updatedContestant.picture}
                    onChange={handleInputChange}
                    placeholder="Picture URL"
                  />
                  <div className="edit-buttons">
                    <button onClick={handleSave} disabled={isSaving}>
                      {isSaving ? 'Saving...' : 'Save'}
                    </button>
                    <button onClick={handleCancel} className="cancel-button">
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="contestant-info">
                    <img src={contestant.picture || '/default-avatar.png'} alt={contestant.name} />
                    <div>
                      <h3>{contestant.name}</h3>
                      <p>Age: {contestant.age}</p>
                      <p>Party: {contestant.partyDescription}</p>
                    </div>
                  </div>
                  <button onClick={() => handleEditClick(contestant)}>Edit</button>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ViewContestants;
