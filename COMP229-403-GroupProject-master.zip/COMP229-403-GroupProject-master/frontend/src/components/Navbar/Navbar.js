import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      {/* Site Name */}
      <div className="site-name-container">
        <h1 className="site-name">COMP 229-403 - Electronic Voting System</h1>
      </div>
      
      {/* Navigation Links */}
      <ul className="nav-links">
        <li>
          <NavLink 
            to="/" 
            className={({ isActive }) => (isActive ? 'active' : '')}
          >
            Home
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/add-contestant" 
            className={({ isActive }) => (isActive ? 'active' : '')}
          >
            Add Contestant
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/view-contestants" 
            className={({ isActive }) => (isActive ? 'active' : '')}
          >
            View Contestants
          </NavLink>
        </li>
        <li>
          <NavLink 
            to="/reset-votes" 
            className={({ isActive }) => (isActive ? 'active' : '')}
          >
            Reset Votes
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
