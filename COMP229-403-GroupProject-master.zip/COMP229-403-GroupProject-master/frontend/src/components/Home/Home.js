import React, { useState, useEffect } from 'react';
import { getContestants } from '../../api/api'; // Updated import to use getContestants
import ContestantCard from '../ContestantCard/ContestantCard';
import './Home.css';

const Home = () => {
  const [contestants, setContestants] = useState([]);

  useEffect(() => {
    const loadContestants = async () => {
      try {
        const contestantsList = await getContestants(); // Corrected API function call
        setContestants(contestantsList); // Directly set the fetched contestants array
      } catch (err) {
        console.error('Error fetching contestants:', err);
      }
    };
    loadContestants();
  }, []);

  return (
    <div className="home">
      <h2>Contestants</h2>
      <div className="contestants-list">
        {contestants.map((contestant) => (
          <ContestantCard
            key={contestant._id}
            contestant={contestant}
            onVote={() => {
              // Refresh or update contestants list after voting
              setContestants([...contestants]);
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default Home;
