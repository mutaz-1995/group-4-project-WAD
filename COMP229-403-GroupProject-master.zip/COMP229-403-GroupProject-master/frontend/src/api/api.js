import axios from 'axios';

// Base URL for backend
const API = axios.create({
  baseURL: 'http://localhost:3000/api/votes', // Update this during deployment
});

// Fetch all contestants
export const getContestants = async () => {
  try {
    const response = await API.get('/');
    console.log('Fetched Contestants:', response.data.contestants); // Debug log
    return response.data.contestants; // Return the `contestants` array directly
  } catch (error) {
    console.error('Error fetching contestants:', error);
    throw new Error('Failed to fetch contestants');
  }
};

// Create a new contestant
export const createContestant = async (contestant) => {
  try {
    const response = await API.post('/contestant', contestant);
    console.log('Contestant Created:', response.data); // Debug log
    return response.data;
  } catch (error) {
    console.error('Error creating contestant:', error);
    throw new Error('Failed to create contestant');
  }
};

// Cast a vote for a contestant
export const castVote = async (contestantId, voterName = 'Anonymous') => {
  try {
    const response = await API.post('/vote', { contestantId, voterName });
    console.log('Vote Cast:', response.data); // Debug log
    return response.data;
  } catch (error) {
    console.error('Error casting vote:', error);
    throw new Error('Failed to cast vote');
  }
};

// Get vote count for a specific contestant
export const getVoteCount = async (contestantId) => {
  try {
    const response = await API.get(`/${contestantId}/votes`);
    console.log('Vote Count:', response.data); // Debug log
    return response.data;
  } catch (error) {
    console.error('Error fetching vote count:', error);
    throw new Error('Failed to fetch vote count');
  }
};

// Reset all votes to zero
export const resetVotes = async () => {
  try {
    const response = await API.post('/reset');
    console.log('Votes Reset:', response.data); // Debug log
    return response.data;
  } catch (error) {
    console.error('Error resetting votes:', error);
    throw new Error('Failed to reset votes');
  }
};

// Delete a specific contestant
export const deleteContestant = async (contestantId) => {
  try {
    const response = await API.delete(`/contestant/${contestantId}`);
    console.log('Contestant Deleted:', response.data); // Debug log
    return response.data;
  } catch (error) {
    console.error('Error deleting contestant:', error);
    throw new Error('Failed to delete contestant');
  }
};

// Update contestant details
export const updateContestant = async (id, updatedData) => {
  try {
    const response = await API.patch(`/contestant/${id}`, updatedData);
    console.log('Contestant Updated:', response.data); // Debug log
    return response.data;
  } catch (error) {
    console.error('Error updating contestant:', error);
    throw new Error('Failed to update contestant');
  }
};
