import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar/Navbar';
import Home from './components/Home/Home';
import AddContestant from './components/AddContestant/AddContestant';
import ResetVotes from './components/ResetVotes/ResetVotes';
import ViewContestants from './components/ViewContestants/ViewContestants';

const App = () => {
  return (
    <Router>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/add-contestant" element={<AddContestant />} />
          <Route path="/view-contestants" element={<ViewContestants />} />
          <Route path="/reset-votes" element={<ResetVotes />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
