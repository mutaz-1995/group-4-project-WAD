const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors'); // Import CORS
const voteRoutes = require('./routes/routes');

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Enable CORS
app.use(cors());

// Use vote routes
app.use('/api/votes', voteRoutes);

// MongoDB connection
const mongoURI = 'mongodb+srv://Omazo:a0dV9imI7ETIWCId@cluster0.ocioo.mongodb.net/voterapp?retryWrites=true&w=majority&appName=Cluster0';

mongoose
  .connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
    app.listen(3000, () => {
      console.log('Server running on port 3000');
    });
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });

// Error-handling middleware
app.use((error, req, res, next) => {
  if (res.headersSent) {
    return next(error);
  }
  res.status(error.code || 500).json({ message: error.message || 'An unknown error occurred!' });
});
