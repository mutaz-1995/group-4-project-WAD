const express = require('express');
const router = express.Router();
const voteController = require('../controllers/controller');

// Routes for contestants
router.get('/', voteController.getContestants);
router.get('/contestant/:contestantId', voteController.getContestantById);
router.post('/contestant', voteController.createContestant);
router.delete('/contestant/:contestantId', voteController.deleteContestant);
router.patch('/contestant/:contestantId', voteController.updateContestant); // New route

// Routes for votes
router.post('/vote', voteController.createVote);
router.delete('/vote/:voteId', voteController.deleteVote);
router.get('/:contestantId/votes', voteController.getVoteCount);
router.post('/reset', voteController.resetVotes);

module.exports = router;
