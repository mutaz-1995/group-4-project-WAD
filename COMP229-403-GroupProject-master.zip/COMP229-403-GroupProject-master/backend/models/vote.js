const mongoose = require('mongoose');

const voteSchema = new mongoose.Schema({
  contestantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Contestant', required: true },
  voterName: { type: String, required: true },
});

module.exports = mongoose.model('Vote', voteSchema);
