const mongoose = require('mongoose');

// Contestant Schema Definition
const contestantSchema = new mongoose.Schema({
  name: { type: String, required: true }, // Name is required
  age: { type: Number, required: true }, // Age is required
  partyDescription: { type: String, required: true }, // Party Description is required
  picture: { type: String }, // Optional field for a picture URL
  votes: { type: Number, default: 0 }, // Default vote count is 0
});

// Export the Contestant Model
module.exports = mongoose.model('Contestant', contestantSchema);
