const HttpError = require('../models/http-errors');
const Contestant = require('../models/contestant');
const Vote = require('../models/vote');

/**
 * ****************************************************************Fetch all contestants.
 */
const getContestants = async (req, res, next) => {
  try {
    const contestants = await Contestant.find();
    res.status(200).json({ contestants });
  } catch (err) {
    next(new HttpError('Failed to fetch contestants.', 500));
  }
};

/**
 ***************************************************************** Fetch a specific contestant by ID.
 */
const getContestantById = async (req, res, next) => {
  const contestantId = req.params.contestantId;
  try {
    const contestant = await Contestant.findById(contestantId);
    if (!contestant) {
      return next(new HttpError('Contestant not found.', 404));
    }
    res.status(200).json(contestant);
  } catch (err) {
    next(new HttpError('Fetching contestant failed.', 500));
  }
};

/**
 * ******************************************************************Add a new contestant.
 */
const createContestant = async (req, res, next) => {
  console.log('Incoming Request Body:', req.body); // Debug log

  const { name, age, partyDescription, picture } = req.body;

  if (!name || !age || !partyDescription) {
    return res.status(400).json({ message: 'Name, age, and party description are required.' });
  }

  try {
    const newContestant = new Contestant({
      name,
      age: parseInt(age, 10), // Ensure age is a number
      partyDescription,
      picture: picture || null,
      votes: 0, // Default vote count
    });

    await newContestant.save();
    res.status(201).json({ message: 'Contestant created successfully.', contestant: newContestant });
  } catch (err) {
    console.error('Error creating contestant:', err); // Log any error
    next(new HttpError('Creating contestant failed.', 500));
  }
};



/**
 * ***********************************************************Delete a specific contestant by ID.
 */
const deleteContestant = async (req, res, next) => {
  const contestantId = req.params.contestantId;

  try {
    const result = await Contestant.findByIdAndDelete(contestantId);
    if (!result) {
      return next(new HttpError('Contestant not found.', 404));
    }
    res.status(200).json({ message: 'Contestant deleted successfully.' });
  } catch (err) {
    next(new HttpError('Deleting contestant failed.', 500));
  }
};

/**
 * *************************************************************Cast a vote for a specific contestant.
 */
const createVote = async (req, res, next) => {
  const { contestantId, voterName } = req.body;

  try {
    const contestant = await Contestant.findById(contestantId);
    if (!contestant) {
      return next(new HttpError('Contestant not found.', 404));
    }

    const vote = new Vote({ contestantId, voterName });
    await vote.save();

    contestant.votes += 1;
    await contestant.save();

    res.status(201).json({ message: 'Vote created', vote });
  } catch (err) {
    next(new HttpError('Creating vote failed.', 500));
  }
};

/**
 * **************************************************************Get the vote count for a specific contestant.
 */
const getVoteCount = async (req, res, next) => {
  const contestantId = req.params.contestantId;
  console.log('Received request for vote count of contestant:', contestantId);

  try {
    const contestant = await Contestant.findById(contestantId);
    if (!contestant) {
      console.log('Contestant not found for ID:', contestantId);
      return res.status(404).json({ message: 'Contestant not found.' });
    }

    console.log('Contestant found:', contestant); // Debug log
    res.status(200).json({ contestantId: contestant._id, votes: contestant.votes });
  } catch (err) {
    console.error('Error fetching vote count:', err); // Debug log
    return next(new HttpError('Fetching vote count failed.', 500));
  }
};

/**
 * *****************************************************************Delete a specific vote by vote ID.
 */
const deleteVote = async (req, res, next) => {
  const { voteId } = req.params;

  try {
    const vote = await Vote.findByIdAndDelete(voteId);
    if (!vote) {
      return next(new HttpError('Vote not found.', 404));
    }

    const contestant = await Contestant.findById(vote.contestantId);
    if (contestant) {
      contestant.votes -= 1;
      await contestant.save();
    }

    res.status(200).json({ message: 'Vote deleted successfully.' });
  } catch (err) {
    next(new HttpError('Deleting vote failed.', 500));
  }
};

/**
 * **************************************************************Reset votes for all contestants to zero.
 */
const resetVotes = async (req, res, next) => {
  console.log('Resetting all votes'); // Debug log

  try {
    const result = await Contestant.updateMany({}, { votes: 0 });
    console.log('Reset result:', result); // Debug log
    res.status(200).json({ message: 'All votes have been reset.' });
  } catch (err) {
    console.error('Error resetting votes:', err); // Debug log
    return next(new HttpError('Resetting votes failed.', 500));
  }
};



/**
 * **************************************************************Update contestants records.
 */
const updateContestant = async (req, res, next) => {
  const { contestantId } = req.params;
  const { name, age, partyDescription, picture } = req.body;

  try {
    const updatedContestant = await Contestant.findByIdAndUpdate(
      contestantId,
      { name, age, partyDescription, picture },
      { new: true, runValidators: true }
    );

    if (!updatedContestant) {
      return next(new HttpError('Contestant not found.', 404));
    }

    res.status(200).json({ message: 'Contestant updated successfully.', contestant: updatedContestant });
  } catch (err) {
    console.error('Error updating contestant:', err);
    next(new HttpError('Updating contestant failed.', 500));
  }
};
exports.updateContestant = updateContestant;











// Export all controller functions
exports.getContestants = getContestants;
exports.getContestantById = getContestantById;
exports.createContestant = createContestant;
exports.deleteContestant = deleteContestant;
exports.createVote = createVote;
exports.getVoteCount = getVoteCount;
exports.deleteVote = deleteVote;
exports.resetVotes = resetVotes;
